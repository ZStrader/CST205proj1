from PIL import Image
import array

print "cool"

for n in range(1,9,1):
    currentImage = Image.open('Project1Images/' + (str(n) + '.png'))
    #imageList = []
    #imageList.append(currentImage)
    width, height = currentImage.size
    rgbarray = [[[0 for w in range(3)] for x in range((width * height) + 1)] for y in range(10)]
    for o in range(0, width, 1 ):
        for p in range(0, height, 1):
            rgb_image = currentImage.convert('RGB')
            r, g, b = rgb_image.getpixel((o, p))
            #rgbarray[0][z][n] = o            # nvm = x coordinates
            #rgbarray[1][z][n] = p            # nvm = y coordinates
            rgbarray[0][o + p][n] = r            # 0 = red value
            rgbarray[1][o + p][n] = g            # 1 = green value
            rgbarray[2][o + p][n] = b            # 2 = blue value
            
            r = 0
            g = 0
            b = 0
            print rgbarray[0][o + p][n]
            """for t in range(1, 20, 1):
            if rgbarray[1][q][t] == null:
            rgbarray[1][q][10] = rgbarray[1][q][10] + rgbarray[1][q][n]
            rgbarray[2][q][10] = rgbarray[2][q][10] + rgbarray[2][q][n]
            rgbarray[3][q][10] = rgbarray[3][q][10] + rgbarray[3][q][n]"""

print r, g, b
#(65, 100, 137)