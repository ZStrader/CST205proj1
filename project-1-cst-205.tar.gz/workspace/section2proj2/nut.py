print "cool beans"
# wow 
print "haha nice one"